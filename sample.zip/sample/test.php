<?php

echo $_POST['oName'];
echo $_POST['top'];
echo $_POST['bottom'];

?>